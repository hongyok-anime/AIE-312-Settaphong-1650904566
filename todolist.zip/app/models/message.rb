class Message < ApplicationRecord
  belongs_to :room
end
