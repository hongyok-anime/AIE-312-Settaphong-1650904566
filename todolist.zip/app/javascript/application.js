// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
// ตัวอย่างไฟล์ application.js ของคุณ
import Rails from '@rails/ujs';
Rails.start();
