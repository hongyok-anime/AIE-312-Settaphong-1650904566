class MessagesController < ApplicationController
  # GET /messages
  def index
    @messages = Message.all
  end

  # GET /messages/new
  def new
    @message = Message.new
    @room = Room.find(params[:room_id]) if params[:room_id] # ดึง room ถ้ามีการส่ง id มาจาก params
  end

  # GET /messages/1 or /messages/1.json
  def show
    @message = Message.find_by(id: params[:id])
    if @message.nil?
      flash[:alert] = "Message not found."
      redirect_to messages_path
    end
  end

  # POST /messages or /messages.json
  def create
    @message = Message.new(message_params)

    if @message.room_id.nil? || !Room.exists?(@message.room_id)
      respond_to do |format|
        format.html { redirect_to new_message_path, alert: "Invalid room ID." }
        format.json { render json: { error: "Invalid room ID." }, status: :unprocessable_entity }
      end
      return
    end

    respond_to do |format|
      if @message.save
        if @message.room.present?
          @message.broadcast_append_to @message.room, partial: @message, locals: { message: @message }, target: "messages"
        end
        format.turbo_stream
        format.html { redirect_to @message, notice: "Message was successfully created." }
        format.json { render :show, status: :created, location: @message }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @message.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /messages/1 or /messages/1.json
  def destroy
    @message = Message.find_by(id: params[:id])

    if @message
      if @message.room.present?
        @message.broadcast_remove_to @message.room, target: @message
      end
      @message.destroy!

      respond_to do |format|
        format.turbo_stream
        format.html { redirect_to messages_path, status: :see_other, notice: "Message was successfully destroyed." }
        format.json { head :no_content }
      end
    else
      respond_to do |format|
        format.html { redirect_to messages_path, alert: "Message not found." }
        format.json { render json: { error: "Message not found" }, status: :not_found }
      end
    end
  end

  private

  def message_params
    params.require(:message).permit(:content, :room_id)
  end
end
