class HomeController < ApplicationController
  def index
    @rooms = Room.all
    if params[:room_id].present?
      @room = Room.find_by(id: params[:room_id])
      if @room.nil?
        flash[:alert] = "Room not found"
        redirect_to home_index_path 
      end
    end
  end
end
