// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
function markAsComplete(taskId) {
    const taskElement = Array.from(document.querySelectorAll('#incomplete-tasks li')).find(li => {
        return li.querySelector('span').innerText.includes(taskId);
    });

    if (taskElement) {
        const completeTasksList = document.getElementById('complete-tasks');
        const newTaskHtml = `
            <li>
                <span>${taskId} - complete</span>
                <button onclick="deleteTask('${taskId}', true)">Delete</button>
            </li>
        `;
        completeTasksList.insertAdjacentHTML('beforeend', newTaskHtml);
        taskElement.remove(); // ลบจากรายการที่ยังไม่เสร็จ
    }
}

function deleteTask(taskId, isComplete = false) {
    const listId = isComplete ? 'complete-tasks' : 'incomplete-tasks';
    const taskElement = Array.from(document.querySelectorAll(`#${listId} li`)).find(li => {
        return li.querySelector('span').innerText.includes(taskId);
    });

    if (taskElement) {
        taskElement.remove(); // ลบ task ออกจาก DOM
    }
}

function addTask() {
    const taskTitle = document.getElementById('taskTitle').value;
    if (taskTitle) {
        const newTaskHtml = `
            <li>
                <span>${taskTitle} - incomplete</span>
                <button onclick="markAsComplete('${taskTitle}')">Mark as Complete</button>
                <button onclick="deleteTask('${taskTitle}', false)">Delete</button>
            </li>
        `;
        document.getElementById('incomplete-tasks').insertAdjacentHTML('beforeend', newTaskHtml);
        document.getElementById('taskTitle').value = ''; // เคลียร์ input
    }
}
